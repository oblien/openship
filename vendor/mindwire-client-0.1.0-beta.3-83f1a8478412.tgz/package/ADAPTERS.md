# Chat adapter reference

An adapter connects one chat to your backend. Give `ChatProvider` a stable adapter
instance and `authConfig={{ sessionId }}`. Recreate both when the conversation changes.
Set `autoLoadHistory` on the provider to fetch the first page on mount, or call
`useChatContext().getHistory()` when the host controls initialization.
Backend credentials and session ownership remain the host application's responsibility.

## Required operations

Import `ChatApiHandler`, `HistoryRequest` and `HistoryPage` from `@mindwire-ai/client`.

| Operation | Contract |
| --- | --- |
| `sendMessage(params, emit)` | Start work; call `emit(JSON.stringify(event) + '\n')` for each event; resolve `{ status: true }` when the connection closes. |
| `getHistory({ cursor?, offset?, limit? })` | Return `{ history, has_more, nextCursor? }`. History is oldest first within each page. |
| `abort()` | Detach the current reader. This must not cancel server-side work. |

`sendMessage` receives `messageId`, `message`, `sessionId`, `attachedFiles` and
optional inline `attachments`. Use `messageId` as a stable request identifier
when your server supports idempotent submission.

History rows use `messageId`, `sender: 'user' | 'ai'`, `type`, `text` and a
millisecond `timestamp`. Give every saved item a stable identity. For text-only
assistant rows use `type: 'ai'`; thinking rows use `type: 'thinking'`.

When `nextCursor` is present, Load more passes it back as `cursor`. The adapter
treats it as opaque. Without a cursor the UI supports legacy `{ offset, limit }`
pagination. `has_more: false` ends pagination. Loading failures preserve the
existing messages; overlapping saved rows are deduplicated by `messageId`.

## Stream events

Each record is `{ event, data }`:

| Event | Data |
| --- | --- |
| `ai_response` | `{ messageId, content, isLive?, replace?, stableId? }` |
| `ai_thinking` | `{ messageId, content, isLive?, replace?, stableId? }` |
| `status_update` | `{ messageId, taskId, kind, name, state, label, metadata? }` |
| `human_interaction` | `{ request }`, using the interaction shape in the exported adapter types |
| `stream_error` | `{ errorType, message }` |
| `ai_response_end` | `{ status: 'end' }` |

Text appends by default. Set `replace: true` for a cumulative or corrected
snapshot of that item, including an empty replacement. `isLive: false` renders
saved output immediately. Keep text item IDs stable across reconnects and use
distinct IDs for distinct text or thinking blocks.
Set `stableId: true` when IDs already identify individual blocks, so an interleaved
tool update does not split that block into a new visual message.

Tool status uses `kind: 'tool'`, a stable `taskId`, and `state: 'started'`,
`'in_progress'`, `'finished'`, `'failed'` or `'cancelled'`. Input and output can
be included in `metadata.args`, `metadata.content` and `metadata.is_error`.

End-of-connection is not end-of-work. Emit `ai_response_end` only when work has
settled; a lost connection should be recoverable through the run methods.

## Optional operations

| Operation | Used for |
| --- | --- |
| `abortRequest(sessionId)` | Explicit Stop: cancel the server's current work. |
| `getRunStatus(sessionId)` | Discover running work after reload or disconnect. |
| `attachRun(sessionId, emit)` | Subscribe to existing work without sending another prompt. |
| `getHumanInteractions(sessionId)` | Restore approvals and questions after reload. |
| `respondToHuman(sessionId, requestId, response)` | Submit the chosen action and field values. |
| `getConversationControls` / `submitConversationInput` | Advertise and send input during a running response. |

The TypeScript interface describes the complete optional surface. Implement only
operations your backend supports. Global access-mode changes, goal controls and
context compaction are separate capabilities; supporting approval forms does
not imply supporting those controls.
Set `supportsLive: false` for adapters without the MindWire voice/live protocol;
this disables the provider's automatic live WebSocket connection.

Adapters that replay the entire response use the default `replayMode: 'full'`.
An adapter using event cursors sets `replayMode: 'incremental'` so reconnection
preserves text already on screen. It must deduplicate replayed events itself.

## Callback adapter

`createCallbackApiHandler` wraps callbacks into this interface. Its `sendMessage`
callback receives `{ params, streamCallback, config, handler }`; `getHistory`
receives `{ params, config, handler }`. This is useful when an application already
owns its fetch, authentication and stream handling.
