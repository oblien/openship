# Mindwire integration

Import `createMindwireAdapter` from `@mindwire-ai/client/mindwire`. The entry point
contains a browser transport and adapter; it has no dependency on the MindWire
server or on the Mindwire daemon binary.

## Connection

```ts
const adapter = createMindwireAdapter({
  baseUrl: '/mindwire',
  chatId: 'project-chat',
  agent: 'codex',
  cwd: '/work/my-project',
  // Optional: getToken: async () => currentSessionToken(),
});
```

Use this adapter as `ChatProvider`'s `apiHandler`, with
`authConfig={{ sessionId: 'project-chat' }}`. The quickstart is in [README](README.md).
Import `@mindwire-ai/client/ui.css` once and give the chat container an explicit height.

`baseUrl` points to an existing daemon or an application proxy. `getToken` is
called for each request, so token rotation does not require recreating the adapter.
`headers`, `fetch` and `timeoutMs` are optional. The timeout applies to ordinary
HTTP requests; the streamed response remains open until work settles or you detach.

The application owns authentication and access to the selected computer, agent,
project and conversation. An authenticated proxy can attach the daemon credential
on the server. Use the daemon's working-directory path for `cwd`.

An existing Mindwire SDK client can be supplied instead:

```ts
const adapter = createMindwireAdapter({ client: mw, chatId, cwd });
```

The client is accepted through a structural interface; the React package does
not import or bundle the SDK. Use `baseUrl` for a browser-only installation.

## Operations

| Chat behavior | Mindwire operation |
| --- | --- |
| Send / reply | `turn` with a stable request ID |
| Initial history / Load more | `messagePage`, using the returned `before` cursor |
| Text / thinking | Stream deltas append; snapshots replace the identified item |
| Tool activity | `tool_use` and `tool_result` share the tool-call identity |
| Reconnect | Run snapshot, then stream after its sequence; subsequent reads retain the cursor |
| Stop | Cancel the current run |
| Unmount / `dispose()` | Detach the reader while server-side work continues |
| Approvals / questions | Snapshot interactions and `respond` |
| Message while working | `sendInput` when the run advertises the `input` capability |
| Files | Composer files become Mindwire attachments |

The adapter uses the daemon's paged history and run snapshot APIs. Update older
daemons before using it. It determines completion from the durable run status,
so a child iteration's result or a dropped stream does not finish the whole reply.

Use `onEvent` to observe original Mindwire events, including events that do not
have a built-in visual. Transport errors and backend errors surface through the
chat's error state. Failed approval submissions remain answerable.

## Lifecycle and capabilities

Create one adapter per mounted chat with `useMemo`. Call `adapter.dispose()` in
the component's effect cleanup. Recreate the adapter and use `key={chatId}` on
`ChatProvider` when the selected chat changes.

Pass `inputProps={{ enableLive: false }}` to `DefaultPanel`: native voice is a
separate Mindwire protocol and is not implemented by this adapter. Global tool
access modes, MindWire goals, automatic checkpoint retries and context inspection
are not advertised by this integration. Agent-defined approvals and questions
remain available independently of those features.
