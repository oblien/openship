# One client, application-owned capabilities

`@mindwire-ai/client` provides the shared browser UI for application assistants.
Internal workspace imports stay unchanged. Existing `ChatProvider`, `DefaultPanel`,
`ChatCore`, adapters and message formats continue to work. Compact tools are opt-in.

## Compact tools

```tsx
import { ChatProvider, DefaultPanel, type ToolActivityConfig } from '@mindwire-ai/client';
import '@mindwire-ai/client/ui.css';

const tools: ToolActivityConfig = {
  mode: 'inline',
  describeTool(call) {
    if (call.name === 'records.search') return { label: 'Search records' };
  },
  renderDetails({ call, content, loading, error, defaultContent }) {
    // Application-specific components and validated result schemas belong here.
    // Return undefined for the client's safe default input/output view.
    if (call.name !== 'records.search' || loading || error) return undefined;
    return <section><p>Search result</p>{defaultContent}</section>;
  },
};

// apiHandler comes from the application's authenticated chat API.
<ChatProvider key={chatId} apiHandler={apiHandler}
  authConfig={{ sessionId: chatId }} tools={tools}>
  <DefaultPanel inputProps={{ enableLive: false }} />
</ChatProvider>;
```

The client projects its existing normalized messages into inline buttons. Adjacent
calls may share a button, but prose, reasoning, user messages, agent messages and
custom `statusComponents` remain boundaries. Calls keep their original order and
individual input, output and status. Both virtualized and ordinary transcripts use
the same projection. History and live responses use the same renderer.

`describeTool` can provide a label, React icon and group key. Set
`groupConsecutive: false` for one button per call. `labels` overrides all text in
the generic tool UI, including status labels and call counts.

`renderDetails` and `renderActions` mount only while the dialog is open. Their
props include the selected `call`, `args`, `content`, `loading`, `error`, `isError`,
`retry()`, `close()` and `defaultContent`. Returning `undefined` from
`renderDetails` retains the default; returning `null` intentionally hides it.
App navigation and specialized result views stay in these callbacks. Validate
untrusted tool output before interpreting it; the default displays it as escaped text.

Tool IO is fetched through the existing adapter only on expansion. Completed
results cache in the owning chat's message store, never in a global cache.
Late results from closed or switched views are ignored. Terminal activity uses
the existing detail stream, which disconnects on close. `ToolActivity`,
`getToolCall`, `groupToolCalls` and `useToolIo` are exported for custom layouts.

## Embed the existing composer

For a right sidebar, use the existing transcript and composer in a flex column:

```tsx
import { ChatCore, ChatInputDefault } from '@mindwire-ai/client';

<div className="react-ai-agent" data-theme={isDark ? 'dark' : 'light'} style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
  <div style={{ flex: 1, minHeight: 0 }}>
    <ChatCore contentPaddingStart={16} contentPaddingEnd={24} useGradientMask={false} />
  </div>
  <ChatInputDefault layout="inline" mode="default" placeholder="Ask about this page"
    enableLive={false} enableAttachments={false} showOptions={false}
    toolbarContent={<YourModelPicker />} />
</div>;
```

Mount this under `ChatProvider`; use your app's theme state or `useResolvedTheme()`
for `isDark`. The composer uses its send, streaming and stop
state automatically; explicit handler props still override these defaults.
Approvals, command parsing, attachments and sending while working retain their
existing paths. `disabled` disables editing/sending while keeping Stop available.
The default `floating` layout is unchanged. Hosts that need a custom input can
reuse `useComposerCommands`, `useAttachments` and `ComposerActions`.

The UI inherits the application's font and theme tokens: `--text-primary`,
`--text-tertiary`, `--bg-elevated`, `--bg-muted`, and optional `--text-danger`.
Dialogs retain those variables in the browser top layer. Light/dark defaults
work without a host design system; logical spacing supports RTL.

## Application boundaries

Use one keyed provider and adapter per conversation. The client owns parsing,
streaming, message storage, rendering, history, cancellation and interaction UI.
Each application owns its authenticated API, organization/mailbox authorization,
allowed tools, consent, approval policy and provider credentials. Render callbacks
and hidden buttons are presentation options, never permission enforcement.

Installing the client does not install a runtime or grant tool access. Applications
retain their existing authentication and enforce permissions on every server request.

## Existing application subscriptions

When the application already owns an authorized native subscription, use
`ChatSnapshotProvider` with its current messages, activity, pagination callbacks
and controls. It never starts a second transport. Normalize native daemon messages
with `normalizeMindwireMessages` from `@mindwire-ai/client/mindwire`; the remote
adapter uses this same projection. Include the account/workspace in `sessionId`.
`transform` can assign a registered status action to a host-owned review card.
Keep approvals and resource access with the application's existing handlers.

Arriving snapshot text uses the same word reveal as the streaming adapter. Restored
history is immediate, and corrections replace text rather than replaying it. Pass
`animate={false}` for a hidden/inactive view or an instant presentation. Reduced
motion is respected. The packaged stylesheet includes the Markdown blur animation;
hosts do not need a separate Streamdown stylesheet import.

Use `tools.renderTrigger` to retain your design system's button. Spread its
`buttonProps` onto the button and render its `children` inside; the shared client
continues to own grouping, accessible labels, dialog selection and focus restoration.

Custom themed composers can use `useChatComposer` with existing controls. It shares
command handling, IME/touch-aware submission, resize-on-width-change and submission
locking. The host continues to own its draft and attachment validation. For the
provided `ChatInputDefault`, `value`, `onValueChange`, `inputRef`, `canSend`,
`canSendWhileStreaming` and `showActivityGlow` support the same controlled embedding.
A controlled draft is cleared by the host after its accepted submission.

`ChatCore.footer` places host activity and reserved composer space inside the measured
timeline. `showConversationNavigator` enables turn navigation and a jump to the latest
message without pulling readers away from earlier content.
History pagination stays at the start of the scrollable timeline. The top edge fades
over 24px only when scrolled; it does not mask the fixed navigation controls.

`renderInline` in tool configuration can display validated receipts and resource links
beside tool buttons. Its `open(callId)` callback opens details for that specific call.
Use `ChatMarkdown` for the same safe parser outside the transcript. Hosts can supply
`markdownComponents` for links and code controls. `copyText` remains available through
the chat context for host clipboard controls; responses have no automatic Copy button.
Model-generated images do not load remotely.
