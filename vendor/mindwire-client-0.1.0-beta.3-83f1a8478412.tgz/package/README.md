# @mindwire-ai/client

React chat components for your agent backend. Render streamed replies, thinking,
tool activity, message history, attachments and approval forms in your application.
Use the included Mindwire adapter or implement the chat adapter interface for your API.

## Install

```sh
npm install @mindwire-ai/client@beta react react-dom
```

The package contains the React UI, browser contracts and Mindwire integration.
It does not install the MindWire runtime, server, database or SDK.
React 18.2 and React 19 are supported. This is an ESM package; use `import`.
Import the stylesheet once.

## Connect to Mindwire

```tsx
'use client';

import { useEffect, useMemo } from 'react';
import { ChatProvider, DefaultPanel } from '@mindwire-ai/client';
import { createMindwireAdapter } from '@mindwire-ai/client/mindwire';
import '@mindwire-ai/client/ui.css';

export function AgentChat({ chatId }: { chatId: string }) {
  const adapter = useMemo(() => createMindwireAdapter({
    baseUrl: '/mindwire',
    chatId,
    agent: 'codex',
  }), [chatId]);

  useEffect(() => () => adapter.dispose(), [adapter]);

  return (
    <div style={{ height: '100dvh' }}>
      <ChatProvider autoLoadHistory key={chatId} apiHandler={adapter} authConfig={{ sessionId: chatId }}>
        <DefaultPanel inputProps={{ enableLive: false }} />
      </ChatProvider>
    </div>
  );
}
```

`/mindwire` is an authenticated application proxy to a running Mindwire daemon.
The adapter does not start the daemon. An absolute daemon URL also works when
that server permits the browser's origin and authenticates its requests.

The adapter wires sending, history pagination, text snapshots, reconnection,
tool activity, approvals and supported input while working. Voice controls are
disabled in this example because this adapter does not implement the voice protocol.

See [Mindwire integration](MINDWIRE.md) for connection options and supported operations.

## Use your own backend

Pass a stable `apiHandler` to `ChatProvider`. It supplies `sendMessage`, `getHistory`
and `abort`, with optional cancellation, reattachment and interaction methods.
The components render the resulting events and own loading, scrolling and animation.
See [the adapter reference](ADAPTERS.md).

## Customize

See [embedding and inline tools](EMBEDDING.md) for compact activity, application
result renderers, theme tokens and a sidebar using the existing composer.

- Set `initialWelcome={{ title, description }}` on `ChatProvider`.
- Pass `isDark` to `DefaultPanel`, or let it follow the host theme.
- Supply `markdownComponents`, `statusComponents` and loading components to `ChatProvider`.
- Compose your own screen with `ChatCore`, `ChatInputDefault` and `useChatContext`.
- Mount a separate provider and adapter for each chat. Use `key={chatId}` when switching chats.

Next.js applications should render the chat inside a Client Component and import
`ui.css` once from their layout or stylesheet entry. The package exports its own
compiled CSS; Tailwind configuration is not required in the consuming application.

## License

MIT. See [LICENSE](LICENSE).
